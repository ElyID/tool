Tools installer

pkg upgrade 
pkg update
pkg install git -y
pkg install python2 -y
git clone https://github.com/ezaID/tools
cd tools
python2 install.py
